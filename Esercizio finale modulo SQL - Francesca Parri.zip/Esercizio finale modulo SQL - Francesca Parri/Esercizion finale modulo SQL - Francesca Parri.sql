-- Creo il Database ToysGroup da popolare con le entità 
create database ToysGroup;
-- drop database ToysGroup; -- Per eventualmente cancellare tutto il Database e ricrearlo da capo

-- Chiedo di utilizzare proprio il Database ToysGroup per le istruzioni successive
use ToysGroup;

-- Creo le varie tabelle sulla base della progettazione logica del mio Database

create table Category (
		CategoryID mediumint
		, CategoryName varchar(50)
        , CategoryDescription varchar(100)
        -- Ora creo la Primary Key dando un nome al constraint
		, constraint PK_Category primary key (CategoryID)
);
create table Product (
		ProductID mediumint
        , ProductName varchar(50)
        , ProductShortDescription varchar(150)
        , ProductCategoryID mediumint
        , ProductUnitPrice decimal(10,2)
        -- Ora creo la Primary Key e la Foreign Key dando un nome ai constraint
        , constraint PK_Product primary key (ProductID)
        , constraint FK_Category_Product foreign key (ProductCategoryID) references Category (CategoryID)
);


create table Region (
		RegionID mediumint
        ,RegionName varchar(25)
        ,RegionDescription varchar(100)
		-- Ora creo la Primary Key dando un nome al constraint
        , constraint PK_Region primary key (RegionID)
) ;

create table Sales (
		SalesID mediumint
        , Salesdate date
        , SalesSoldProductNumber int
        , SalesProductID mediumint
        , SalesRegionID mediumint
        -- Ora creo la Primary Key e le Foreign Key dando un nome ai constraint
		, constraint PK_Sales primary key (SalesID)
        , constraint FK_Product_Sales foreign key (SalesProductID) references Product (ProductID)
        , constraint FK_Region_Sales foreign key (SalesRegionID) references Region (RegionID)
);

-- Ora popolo le tabelle create inserendo un certo numero di record per ciascuna

insert into Category (CategoryID, CategoryName, CategoryDescription)
values				(1,'Neonati','Neonati include tutti i giochi fino a +1 anno')
					,(2,'Bambini','Bambini include tutti i giochi da +1 a +14 anni, esclusi i libri')
                    ,(3,'LetturaBambini','Solo libri da +1 a +14 anni')
                    ,(4,'DaTavolo','Tutti i giochi da tavolo a prescindere dall età consigliata')
                    ,(5,'Tecnologici','Computer, tablets, robots da +1 a +12')
                    ,(6,'Videogiochi','Console e giochi per console')
                    ,(7,'Videogiochi2','Console e giochi per console')
;

insert into Product (ProductID, ProductNAme, ProductShortDescription, ProductCategoryID, ProductUnitPrice)
values				(1,'Cicciobello','Bambolotto per +3',2,24.99)
					,(2,'Sonaglio','Per neonati da +6 mesi',1,14.99)
                    ,(3,'Pictionary','Gioco da tavolo da +3 a +99',4,29.99)
                    ,(4,'Monopoli','Gioco da tavolo da +3 a +99',4,29.99)
                    ,(5,'Il mio primo computer','Computer interattivo +10 anni',5,149.99)
                    ,(6,'Harry Potter','Per far venire l ansia ai bamibini +10',6, 30.00)
                    ,(7,'Tu sei un supereroe!','Libro per bambini +4',3, 10.49)
;

insert into Region (RegionID, RegionName, RegionDescription)
values				(1, 'Africa', 'Tutto il continente africano, isole comprese')
					,(2, 'America','Tutto il continente americano, isole comprese')
                    ,(3, 'Antartide', 'Antartide')
					,(4, 'Asia', 'Tutto il continente asiatico, isole comprese')
                    ,(5, 'Europa', 'Tutto il continente europeo, isole comprese')
                    ,(6, 'Oceania', 'Tutto il continente australiano e la Nuova Zelanda')
;

insert into Sales (SalesID, SalesProductID, SalesRegionID, Salesdate, SalesSoldProductNumber)
values				(1,5,1,'2020-03-05',3)
					,(2,2,4,'2020-04-05',15)
                    ,(3,1,5,'2020-04-08',1)
                    ,(4,1,6,'2020-04-10',3)
                    ,(5,6,6,'2020-04-10',4)
                    ,(6,7,5,'2020-04-13',5)
                    ,(7,4,5,'2020-04-14',4)
                    ,(8,4,1,'2020-04-14',5)
                    ,(9,5,2,'2020-04-16',20)
                    ,(10,7,2,'2020-04-20',2)
                    ,(11,2,2,'2021-04-05',15)
                    ,(12,1,5,'2021-04-08',1)
                    ,(13,7,4,'2021-04-10',3)
                    ,(14,6,6,'2021-04-10',4)
                    ,(15,7,5,'2021-04-13',5)
                    ,(16,5,5,'2021-04-14',4)
                    ,(17,4,1,'2021-04-14',5)
                    ,(18,2,3,'2021-04-16',20)
                    ,(19,5,2,'2021-04-20',2)
                    ,(20,4,1,'2021-04-22',5)
                    ,(21,2,2,'2022-04-05',15)
                    ,(22,1,5,'2022-04-08',1)
                    ,(23,7,4,'2022-04-10',3)
                    ,(24,6,6,'2022-04-10',4)
                    ,(25,7,5,'2022-04-13',5)
                    ,(26,5,5,'2022-04-14',4)
                    ,(27,4,1,'2022-04-14',5)
                    ,(28,1,3,'2022-04-16',20)
                    ,(29,4,2,'2022-04-20',2)
                    ,(30,4,1,'2022-04-22',5)
;
-- truncate table sales;-- per eventualmente cancellare tutti i record della tabella sales, mantenendo la struttura

-- Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:

-- 1. Verificare che i campi definiti come PK siano univoci. 
/* Per verificare che i campi definiti come PK siano univoci metto a confronto 
la COUNT (xx) della colonna con la "COUNT (distinct xx) della stessa colonna nella */

select  Count(CategoryID)
		,Count(Distinct CategoryID)
from Category;

select  Count(ProductID)
		,Count(Distinct ProductID)
from Product;

select  Count(RegionID)
		,Count(Distinct RegionID)
from Region;

select  Count(SalesID)
		,Count(Distinct SalesID)
from Sales;

-- Faccio la prova del 9 con una colonna dove so esserci dei duplicati es: CategoryDescription
select  Count(CategoryDescription)
		,Count(Distinct CategoryDescription)
from Category;


-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
/* 
Per ottenere i soli prodotti venduti faccio una inner join tra sales e product.
Le due tabelle comunicano attraverso l'ID del prodotto.

Per calcolare il totale delle vendite:
1. moltiplico il prezzo unitario della tab. Product e per il n° di pezzi venduti della tab. Sales
2. faccio poi la somma per anno e productname (grazie a group by) e le do l'alias di "FatturatoTotale"

Raggruppo per ProductName e per anno di acquisto (anno di acquisto ottenuto utilizzando la "year" della Salesdata)
*/

select 		ProductName
			,year(SalesDate) as AnnoVendita
            ,sum(SalesSoldProductNumber*ProductUnitPrice) as FatturatoTotale      
from sales
inner join product
on SalesProductID=ProductID
group by 	productname
			,year(salesdate)
order by Productname asc;



-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

select 		RegionName
			,year(SalesDate) as AnnoVendita
            ,sum(SalesSoldProductNumber*ProductUnitPrice) as FatturatoTotale      
from region
inner join sales
on RegionID=SalesRegionID
join product
on SalesProductID=ProductID
group by 	RegionName
			,year(salesdate)
order by 	year(salesdate)
			,fatturatoTotale desc
;

-- 4.Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
-- Interpreto la domanda come categoria che ha venduto il maggiore numero di pezzi 

select	subquery1.CategoryName
		,subquery1.TotalePezziVenduti

from	(select		Categoryname
					,sum(SalesSoldProductNumber) as TotalePezziVenduti
		from sales
		inner join product
		on SalesProductID=ProductID
		inner join category
		on ProductCategoryID=CategoryID
		group by CategoryName
        ) as Subquery1
    
having subquery1.TotalePezzivenduti= 	(select 		max(Subquery2.TotalePezziVenduti)
										from	(select		Categoryname
															,sum(SalesSoldProductNumber) as TotalePezziVenduti
												from sales
												inner join product
												on SalesProductID=ProductID
												inner join category
												on ProductCategoryID=CategoryID
												group by CategoryName
                                                ) as Subquery2
										) 
;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 

/* Primo approccio: sfrutto la left join partendo dalla tab. product e sulla tab. sales e cerco quei prodotti che hanno SalesID nulla,
   ovvero che non hanno nessuna corrispondenza in Sales perché non sono mai stati venduti*/
select	ProductID
		,ProductName
        ,SalesID
from product
left join sales
on ProductID=SalesProductID
where SalesID is null
;

-- Secondo approccio: uso una subquery per cercare i prodotti venduti e poi escludo questi prodotti

select	ProductID
		,ProductName
from Product
where ProductID not in	(select distinct SalesProductID
						from Sales)
;
-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

select distinct ProductName
				,max(SalesDate) as UltimaDataVendita
from sales
inner join product
on SalesProductID=ProductID
group by productName
;